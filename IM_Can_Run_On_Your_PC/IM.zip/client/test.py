import os

print()